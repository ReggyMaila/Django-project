# JavaScript OO

### 1. Which of the following is a template that defines the shape of an object that is created?

- [x] Class

### 2. Which of the following describes a feature which we would expect from a programming language that supported first class functions?

- [x] The ability to define a function and assign the function to a variable

### 3. What keyword / predefined variable is used in a JavaScript class definition to refer to the "current instance" of the class?

- [x] this

### 4. What do these two statements in JavaScript accomplish? data.stuff = "hello"; data['stuff'] = "hello";

- [x] These two statements accomplish the same thing

### 5. How is the constructor defined in a JavaScript class compared to how the constructor is defined in a Python class?

- [x] A Python constructor is a method named __init__() and a JavaScript constructor is code in the outer function definition